#version 140

#define SHADER_COMPOSITE21
#define NETHER
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/composite21.glsl"
