#version 140

#define SHADER_PREPARE1
#define NETHER
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/prepare1.glsl"
