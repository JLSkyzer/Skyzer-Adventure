#version 140

#define SHADER_GBUFFERS_BEACONBEAM
#define NETHER
#define FSH

#include "/basics/settings.glsl"
#include "/basics/uniforms.glsl"
#include "/generated/common.glsl"
#include "/basics/common.glsl"

#include "/program/gbuffers_beaconbeam.glsl"
