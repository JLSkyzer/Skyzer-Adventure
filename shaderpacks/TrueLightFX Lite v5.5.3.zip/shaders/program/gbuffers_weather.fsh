#define gbuffers_weather

#include "/shader.h"

uniform sampler2D texture;
uniform int isSnow;

varying vec2 texUV;
varying vec4 color;

void main() {
   vec4 albedo = texture2D(texture, texUV) * color;

   float alphaMultiplier = mix(RAIN_INTENSITY * 1.5, 0.8, float(isSnow == 1));
   albedo.a *= alphaMultiplier;
   
   if (isSnow == 0) {
      albedo.rgb = mix(albedo.rgb, vec3(0.6, 0.65, 0.7), 0.5);
   }

   gl_FragData[0] = albedo;
}
