#define gbuffers_textured_lit

#include "/shader.h"

uniform int entityId;
uniform sampler2D texture;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform vec4 entityColor;

varying float fogMix;
varying float isLava;
varying float torchStrength;
varying vec2 lightUV;
varying vec2 texUV;
varying vec3 worldPos;
varying vec4 ambient;
varying vec4 color;
varying vec3 normal;
uniform float rainStrength;
uniform int isSnow;

#ifdef GLOWING_ORES
   varying float isOre;
#endif

#ifdef HAND_DYNAMIC_LIGHTING
   uniform int heldBlockLightValue;
#endif

#include "/common/math.glsl"
#include "/common/getTorchColor.fsh"

#ifdef ENABLE_SHADOWS
   uniform vec3 cameraPosition;
   uniform mat4 shadowModelView;
   uniform mat4 shadowProjection;
   uniform mat4 gbufferProjectionInverse;
   uniform sampler2D shadowtex1;

   varying vec3 sunColor;
   varying float diffuse;

   #include "/common/getSunStrength.fsh"
#endif

void main() {
   vec4 albedo  = texture2D(texture, texUV);
   vec4 ambientColor = ambient;

   #ifdef GLOWING_ORES
      if (isOre > 0.5) {
         float oreGlow = squaredLength(rescale(albedo.rgb, vec3(0.65), vec3(1.0)));
         ambientColor.rgb += vec3(2.5, 1.8, 1.0) * oreGlow;
      }
   #endif

   albedo *= color;

   #ifdef ENABLE_SHADOWS

      float sunStrength = max(0.75*isLava, getSunStrength());
      float blueness = (1.0 - sunStrength) * SHADOW_BLUENESS;

      ambientColor.rgb *= 1.0 - SHADOW_DARKNESS;
      ambientColor.g *= 1.0 + 0.3333*blueness;
      ambientColor.b *= 1.0 + blueness;

      float sunBrightness = SUN_BRIGHTNESS * (1.0 - 0.7 * pow3(luma(albedo.rgb)));
      vec3 lightContribution = (sunBrightness * sunStrength) * sunColor;
      ambientColor.rgb *= 1.0 + lightContribution;

   #else
      float sunStrength = max(0.75*isLava, 1.0);
   #endif

   ambientColor.rgb += getTorchColor(ambientColor.rgb);

   float isThunder = float(entityId == 11000);
   albedo.a = mix(albedo.a, 0.15, isThunder);

   albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);

   albedo *= ambientColor;

   vec3 baseFogColor = fogColor;
   #ifdef FOG_ENHANCEMENT
      float fogLuminance = luma(fogColor);
      vec3 goldTint = vec3(1.1, 0.95, 0.7) * fogColor;
      baseFogColor = mix(fogColor, goldTint, smoothstep(0.3, 0.8, fogLuminance));
   #endif

   vec3 finalFogColor = mix(baseFogColor, vec3(0.02, 0.35, 0.55), float(isEyeInWater == 1) * 0.75);
   float finalFogMix  = mix(fogMix, fogMix * 0.75, float(isEyeInWater == 1));
   albedo.rgb = mix(albedo.rgb, finalFogColor, finalFogMix);

   gl_FragData[0] = albedo;
}