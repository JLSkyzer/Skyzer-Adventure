#define gbuffers_basic

#include "/shader.h"

uniform sampler2D texture;
uniform float frameTimeCounter;

varying vec2 texUV;
varying vec4 vertColor;
varying vec2 screenPos;

vec3 hsv2rgb(vec3 c) {
   vec3 p = abs(fract(c.xxx + vec3(0.0, 2.0/3.0, 1.0/3.0)) * 6.0 - 3.0);
   return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

void main() {
   vec4 baseColor = texture2D(texture, texUV) * vertColor;

   float brightness = dot(vertColor.rgb, vec3(1.0));
   bool isOutline = brightness < 0.15 && vertColor.a < 0.95;

   #if OUTLINE_MODE == 0
      gl_FragData[0] = baseColor;

   #elif OUTLINE_MODE == 1
      if (isOutline) {
         gl_FragData[0] = vec4(OUTLINE_R, OUTLINE_G, OUTLINE_B, OUTLINE_OPACITY);
      } else {
         gl_FragData[0] = baseColor;
      }

   #elif OUTLINE_MODE == 2
      if (isOutline) {
         float hue = fract(frameTimeCounter * OUTLINE_SPEED * 0.2);
         vec3 rainbow = hsv2rgb(vec3(hue, 1.0, 1.0));
         gl_FragData[0] = vec4(rainbow, OUTLINE_OPACITY);
      } else {
         gl_FragData[0] = baseColor;
      }

   #elif OUTLINE_MODE == 3
      if (isOutline) {
         float pulse = 0.5 + 0.5 * sin(frameTimeCounter * OUTLINE_SPEED * 3.0);
         float alpha = mix(0.1, OUTLINE_OPACITY, pulse);
         gl_FragData[0] = vec4(OUTLINE_R, OUTLINE_G, OUTLINE_B, alpha);
      } else {
         gl_FragData[0] = baseColor;
      }

   #elif OUTLINE_MODE == 4
      if (isOutline) {
         float hue = fract(0.5 * (screenPos.x + screenPos.y) + frameTimeCounter * OUTLINE_SPEED * 0.15);
         vec3 gradient = hsv2rgb(vec3(hue, 0.9, 1.0));
         gl_FragData[0] = vec4(gradient, OUTLINE_OPACITY);
      } else {
         gl_FragData[0] = baseColor;
      }

   #endif
}
