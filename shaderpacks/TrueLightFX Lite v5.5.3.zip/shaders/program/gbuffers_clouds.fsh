#define gbuffers_clouds

#include "/shader.h"

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform int worldTime;
uniform mat4 gbufferModelViewInverse;
uniform vec3 shadowLightPosition;
uniform float screenBrightness;

varying float fogMix;
varying vec2 texUV;
varying vec2 lightUV;
varying vec3 worldPos;
varying vec4 color;

#include "/common/math.glsl"
#include "/common/getSunColor.vsh"
#include "/common/getAmbientColor.vsh"

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float noise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(vec2 p) {
    float v = 0.0;
    float amp = 0.5;

    for (int i = 0; i < 4; i++) {
        v += amp * noise2D(p);
        p *= 2.0;
        amp *= 0.5;
    }

    return v;
}

void main() {
   vec4 albedo = texture2D(texture, texUV) * color;

   albedo.a = mix(albedo.a, 0.0, fogMix);
   
   vec3 skyColor = getSunColor();
   vec3 ambientColor = getAmbientColor().rgb;

   #if CLOUD_STYLE == 0 // Standard
      vec3 finalFogColor1 = mix(fogColor, vec3(0.02, 0.35, 0.55), float(isEyeInWater == 1) * 0.75);
      albedo.rgb = mix(albedo.rgb, finalFogColor1, 0.6);
      albedo.rgb *= mix(ambientColor, skyColor, 0.5);

   #else // Enhanced
      float time = float(worldTime) * NORMALIZE_TIME;
      vec2 cloudMove = vec2(time * 0.03, -time * 0.02);
      vec2 cloudUV = texUV * 6.0 + cloudMove;

      float detail1 = fbm(cloudUV * 0.8);
      float detail2 = fbm(cloudUV * 2.4) * 0.45;
      float detail3 = fbm(cloudUV * 5.8) * 0.22;
      float density = clamp(detail1 * 0.58 + detail2 + detail3, 0.0, 1.0);

      float altitude = clamp((worldPos.y - 100.0) / 60.0, 0.0, 1.0);
      altitude = max(altitude, smoothstep(0.15, 0.9, texUV.y));

      float coverage = smoothstep(0.3, 0.6, density * altitude);
      float core = smoothstep(0.6, 0.95, density * altitude);

      float shape = mix(coverage, core, 1.0 - (1.0 - texUV.y) * 0.45);
      shape *= smoothstep(0.1, 0.9, texUV.y);
      shape = clamp(shape, 0.2, 1.0);

      vec3 cloudBase = mix(vec3(0.74, 0.78, 0.82), vec3(0.9, 0.94, 0.99), altitude);
      vec3 cloudTop = mix(vec3(0.98, 0.99, 1.0), vec3(1.0, 1.0, 1.0), altitude);
      vec3 colorCloud = mix(cloudBase, cloudTop, density);

      vec3 sunDir = normalize(vec3(0.0, 1.0, 0.07));
      float sunFactor = clamp(dot(vec3(0.0, 1.0, 0.0), sunDir), 0.4, 1.0);
      float highlight = smoothstep(0.7, 1.0, density) * sunFactor;
      colorCloud += highlight * 0.22;

      albedo.rgb = mix(albedo.rgb * 0.5, colorCloud, shape);
      vec3 finalFogColor2 = mix(fogColor, vec3(0.02, 0.35, 0.55), float(isEyeInWater == 1) * 0.75);
      albedo.rgb = mix(albedo.rgb, finalFogColor2, 0.2 * (1.0 - altitude));
      albedo.a = clamp(0.45 + shape * 0.55, 0.0, 1.0);
   #endif

   gl_FragData[0] = albedo;
}