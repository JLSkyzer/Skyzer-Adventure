#define gbuffers_weather

varying vec2 texUV;
varying vec4 color;

uniform vec2 taaOffset;

void main() {
   gl_Position = ftransform();

   #ifdef TAA
      gl_Position.xy += taaOffset * gl_Position.w;
   #endif

   color = gl_Color;
   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
}
