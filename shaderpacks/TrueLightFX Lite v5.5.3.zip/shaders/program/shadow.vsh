#include "/shader.h"

attribute vec4 mc_Entity;

varying vec2 texUV;
varying float alpha;

#include "/common/getShadowDistortion.glsl"

void main() {
   gl_Position = ftransform();

   #if SHADOW_ENTITY == 0
      if (mc_Entity.x > 11000.0 && mc_Entity.x != 31000.0) gl_Position.xyz = vec3(0.0);
   #endif
   
   gl_Position.xyz = getShadowDistortion(gl_Position.xyz);

   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;

   if (mc_Entity.x == 10072.0) {
      alpha = 0.0;
   }
   else {
      alpha = gl_Color.a;
   }

}