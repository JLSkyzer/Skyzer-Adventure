#define gbuffers_clouds

#include "/shader.h"

uniform float fogEnd;
uniform float fogStart;
uniform float near, far;
uniform int fogShape;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

varying float fogMix;
varying vec2 texUV;
varying vec2 lightUV;
varying vec3 worldPos;
varying vec4 color;

#include "/common/math.glsl"
#include "/common/getWorldPosition.vsh"
#include "/common/getFogMix.vsh"

uniform vec2 taaOffset;

void main() {
	gl_Position = ftransform();

#ifdef TAA
	gl_Position.xy += taaOffset * gl_Position.w;
#endif

	color = gl_Color;
	texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;

	worldPos = getWorldPosition();
	fogMix = getFogMix(worldPos);
}