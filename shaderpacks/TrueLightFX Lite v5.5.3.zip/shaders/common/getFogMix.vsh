float getFogMix(vec3 worldPos) {
   #ifndef ENABLE_FOG

      return 0.0;

   #endif

   float len = fogShape == 1 ? max(length(worldPos.xz), abs(worldPos.y)) : length(worldPos);

   #if MC_VERSION >= 11700

      if (fogEnd < far) {
         return rescale(len, min(fogStart, fogEnd), fogEnd);
      }

      #if defined gbuffers_skybasic

         return 0.0;

      #elif defined gbuffers_clouds

         return clamp((len - far) * (near * 0.01), 0.0, 1.0);

      #elif defined OVERWORLD

         float x = worldTime * NORMALIZE_TIME;

         x = clamp(25.0*(x < MIDNIGHT ? SUNSET - x : x - SUNRISE) + 0.3,
                  OVERWORLD_FOG_MIN,
                  OVERWORLD_FOG_MAX);

         float nightFogDensity = 1.0 - clamp(abs((worldTime * NORMALIZE_TIME) - MIDNIGHT) * 10.0, 0.0, 1.0);
         x *= mix(1.0, 0.6, nightFogDensity); 

         x = min(x, 1.0 - rainStrength);
         x = max(x, 0.05);

         vec3 rayDir = normalize(worldPos);
         float b = 0.025; 
         float c = 0.015 * x; 
         
         float t = b * rayDir.y;
         float num_over_den = (abs(t) > 0.0001) ? ((1.0 - exp(-len * t)) / t) : len;
         float fogAmount = c * exp(-(cameraPosition.y - 64.0) * b) * num_over_den;
         
         return 1.0 - exp(-max(fogAmount, 0.0));

      #else

         return smoothstep(0.0, 1.0, rescale(len, 0.5 * far, far));

      #endif

   #else

      gl_FogFragCoord = len;

      return (isEyeInWater > 0) ? 1.0 - exp(-gl_FogFragCoord * gl_Fog.density)
                                 : clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0);

   #endif
}