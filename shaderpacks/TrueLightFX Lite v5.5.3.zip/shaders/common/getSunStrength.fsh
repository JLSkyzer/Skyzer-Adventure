#include "/common/getShadowDistortion.glsl"

float getSunStrength() {
   #if SHADOW_PIXEL > 0

      vec3 pos = worldPos + cameraPosition;
      pos = pos * SHADOW_PIXEL;
      pos = floor(pos + 0.01) + 0.5;
      pos = pos / SHADOW_PIXEL - cameraPosition;

   #else

      vec3 pos = worldPos;

   #endif

   float posDistance = squaredLength(pos);
   if (posDistance >= SHADOW_MAX_DIST_SQUARED || diffuse <= 0.0) {
      return diffuse;
   }

   vec4 shadowView = shadowModelView * vec4(pos, 1.0);
   vec4 shadowClip = shadowProjection * shadowView;

   shadowClip.xyz = getShadowDistortion(shadowClip.xyz);

   vec3 shadowUV = nvec3(shadowClip)*0.5 + 0.5;

   if (shadowUV.z < 1.0 &&
       shadowUV.s > 0.0 && shadowUV.s < 1.0 &&
       shadowUV.t > 0.0 && shadowUV.t < 1.0)
   {
      float shadowFade  = 1.0 - posDistance * INV_SHADOW_MAX_DIST_SQUARED;
      
      #ifdef SMOOTH_SHADOWS
         float shadow = 0.0;
         float texelSize = 1.0 / float(shadowMapResolution);
         float angle = random(floor(gl_FragCoord.xy)) * 2.0 * PI;
         float sinAngle = sin(angle);
         float cosAngle = cos(angle);
         mat2 rotationMatrix = mat2(cosAngle, -sinAngle, sinAngle, cosAngle);
         
         const float GOLDEN_ANGLE = 2.39996323;
         const mat2 goldenRotation = mat2(cos(GOLDEN_ANGLE), -sin(GOLDEN_ANGLE), sin(GOLDEN_ANGLE), cos(GOLDEN_ANGLE));
         vec2 sincosTheta = vec2(1.0, 0.0);
         float invSqrtQuality = 1.0 / sqrt(float(SHADOW_QUALITY));
         float shadowDepthScale = 3.0 / shadowProjection[2].z;
         
         for (int i = 0; i < SHADOW_QUALITY; i++) {
             float r = sqrt(float(i) + 0.5) * invSqrtQuality;
             vec2 offset = rotationMatrix * (sincosTheta * r);
             
             float shadowDepth = texture2D(shadowtex1, shadowUV.st + offset * texelSize * shadowIntervalSize).x;
             shadow += clamp((shadowDepth - shadowUV.z) * shadowDepthScale, 0.0, 1.0);
             
             sincosTheta = goldenRotation * sincosTheta;
         }
         
         return diffuse * (1.0 - shadowFade * shadow / float(SHADOW_QUALITY));
      #else
         float shadowDepthScale = 3.0 / shadowProjection[2].z;
         float shadowDepth = texture2D(shadowtex1, shadowUV.st).x;
         return diffuse * (1.0 - shadowFade * clamp((shadowDepth - shadowUV.z) * shadowDepthScale, 0.0, 1.0));
      #endif
   }

   return diffuse;
}