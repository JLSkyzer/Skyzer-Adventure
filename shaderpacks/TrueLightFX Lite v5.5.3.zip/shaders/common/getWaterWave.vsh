void getWaterWave(inout vec4 position, inout vec4 normal, float random) {

}