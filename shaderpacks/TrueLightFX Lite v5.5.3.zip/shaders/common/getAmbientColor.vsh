vec4 getAmbientColor() {
   float brightness = 1.0 - screenBrightness;
   brightness = 1.0 - brightness * brightness;

   vec4 ambient = texture2D(lightmap, vec2(AMBIENT_UV.s, lightUV.t));
    vec3 vibrantAmbient = ambient.rgb * (1.1 + clamp(luma(ambient.rgb) * 1.0, 0.0, 0.5));
    ambient.rgb = mix(vibrantAmbient, ambient.rgb, brightness);

   return ambient;
}