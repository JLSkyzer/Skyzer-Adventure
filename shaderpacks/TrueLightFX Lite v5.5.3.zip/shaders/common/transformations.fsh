vec2 screen2uv(vec3 screen) {
   return (0.5 * (screen.xy * vec2(gbufferProjection[0].x, gbufferProjection[1].y)) / (screen.z * gbufferProjection[2].w)) + 0.5;
}

vec3 uv2screen(vec2 uv, float depth) {
   vec3 pos = vec3(vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y) * (uv * 2.0 - 1.0) + gbufferProjectionInverse[3].xy, gbufferProjectionInverse[3].z);
   return pos / (gbufferProjectionInverse[2].w * (depth * 2.0 - 1.0) + gbufferProjectionInverse[3].w);
}

vec3 world2screen(vec3 world) {
   return mat3(gbufferModelView) * world;
}