uniform sampler2D texture;

varying vec2 texUV;
varying float alpha;

void main() {
   vec4 albedo = texture2DLod(texture, texUV, 0);

   albedo.a *= alpha;

   if (albedo.a < 0.1) {
      discard;
   }

   #ifdef SMOOTH_SHADOWS
    float shadow = 0.0;
    float texelSize = 1.0 / shadowMapResolution;
    float angle = random(texUV) * 2.0 * PI;
    float sinAngle = sin(angle);
    float cosAngle = cos(angle);
    mat2 rotationMatrix = mat2(cosAngle, -sinAngle, sinAngle, cosAngle);

    for (int i = 0; i < 16; i++) {
        vec2 offset = vec2(random(texUV + vec2(i, i)), random(texUV - vec2(i, i))) * 2.0 - 1.0;
        vec2 rotatedOffset = rotationMatrix * offset;
        float a = texture2DLod(texture, texUV + rotatedOffset * texelSize, 0).a;
        shadow += a;
    }
    albedo.a = shadow / 16.0;
   #endif

   #ifdef PLAYER_SHADOW
      albedo.rgb = getPlayerShadowColor(albedo.rgb);
   #endif

   gl_FragData[0] = albedo;
}