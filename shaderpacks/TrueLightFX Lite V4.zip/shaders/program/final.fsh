#define final

#include "/shader.h"
#extension GL_EXT_frag_depth : enable

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

varying vec2 texUV;

void main() {

   
   // Pass through color
   gl_FragData[0] = texture2D(colortex0, texUV);
}
