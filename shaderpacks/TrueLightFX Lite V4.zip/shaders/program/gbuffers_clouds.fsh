#define gbuffers_clouds

#include "/shader.h"

uniform sampler2D texture;
uniform vec3 fogColor;

varying float fogMix;
varying vec2 texUV;
varying vec4 color;

#include "/common/getSunColor.vsh"
#include "/common/getAmbientColor.vsh"

void main() {
   vec4 albedo = texture2D(texture, texUV) * color;

   albedo.a = mix(albedo.a, 0, fogMix);
   albedo.rgb = mix(albedo.rgb, fogColor, 0.6);

   #ifdef VOLUMETRIC_CLOUDS
      vec3 skyColor = getSunColor(vec3(0,1,0));
      vec3 horColor = getAmbientColor(vec3(0,1,0));

      albedo.rgb = mix(horColor, skyColor, texUV.y);
   #endif

   gl_FragData[0] = albedo;
}