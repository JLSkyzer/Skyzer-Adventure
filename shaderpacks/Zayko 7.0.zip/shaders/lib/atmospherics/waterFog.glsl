#if (WATER_MODE == 1 || WATER_MODE == 3) && !defined SKY_VANILLA && (!defined NETHER || !defined NETHER_VANILLA)
uniform vec3 fogColor;
#endif

vec4 GetWaterFog(vec3 viewPos) {
    float fog = length(viewPos) / waterFogRange * 0.22;
    fog = 1.0 - exp(-2.6 * fog);
    
    #if WATER_MODE == 0 || WATER_MODE == 2
    vec3 waterFogColor = waterColor.rgb * waterColor.a;
    #elif  WATER_MODE == 1 || WATER_MODE == 3
    vec3 waterFogColor = fogColor * fogColor * 0.125;
    #endif
    waterFogColor *= WATER_F * WATER_F * (1.0 - max(blindFactor, darknessFactor));
    waterFogColor *= mix(vec3(0.92, 1.00, 1.04), vec3(0.72, 0.96, 1.08), clamp(fog * 1.1, 0.0, 1.0));

    #ifdef OVERWORLD
    vec3 waterFogTint = lightCol * eBS * shadowFade * 0.9 + 0.1;
    waterFogTint = mix(vec3(0.38, 0.62, 0.72), waterFogTint, 0.65 + 0.35 * sunVisibility);
    waterFogTint *= mix(vec3(0.80, 0.95, 1.10), vec3(1.0), sunVisibility);
    #endif
    #ifdef NETHER
    vec3 waterFogTint = netherCol.rgb;
    #endif
    #ifdef END
    vec3 waterFogTint = endCol.rgb;
    #endif
    waterFogTint = max(waterFogTint, vec3(0.0));
    waterFogTint = sqrt(waterFogTint * length(waterFogTint));

    return vec4(waterFogColor * waterFogTint, fog);
}
