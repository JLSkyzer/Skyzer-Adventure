#version 120
#define DIMENSION_NETHER

#include "/program/gbuffers_skytextured.fsh"
