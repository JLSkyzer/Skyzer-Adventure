// Sky Made By robobo1221 : https://www.shadertoy.com/view/MstBWs

#define rayleighCoeff ((vec3(0.27, 0.58, 1.0)) * 1e-5)	
#define rayleighCoeffSky ((vec3(0.27, 0.53, 1.0) * 5.0) * 1e-5)
#define mieCoeff vec3(0.0000005)						
#define d0(x) (abs(x) + 1e-8)
#define d02(x) (abs(x) + 1e-3)

const vec3 totalCoeff = rayleighCoeff + mieCoeff;

const vec3 totalCoeffSky = rayleighCoeffSky + mieCoeff;
const vec3 totalCoeff2Sky = rayleighCoeffSky + vec3(1.5e-5);

struct WorldDirs {
    vec3 worldDir;
    vec3 worldDirD;
    vec3 upDir;
    vec3 sunDir;
};

struct DotVals {
    float sunLook;
    float moonLook;
    float sunUp;
    float upWorld;
    float upWorldD;
};

struct DepthVals {
    float viewDepth;
    float lightDepth;
};

struct ScatterVals {
    vec3 viewScatter;
    vec3 viewAbsorb;
    vec3 lightScatter;
    vec3 lightAbsorb;
    vec3 sunScatter;
    vec3 sunAbsorb;
};

struct SkyColors {
    vec3 horizon;
    vec3 horizon2;
    vec3 zenith;
    vec3 finalCol;
    vec3 sunEffect;
    vec3 moonEffect;
};

float rayleighPhase(float x){
	return 0.5 * (1.0 + x*x);
}

float hgPhase(float x, float g){
    float g2 = g*g;
	return 0.25 * ((1.0 - g2) * pow(1.0 + g2 - 2.0*g*x, -1.5));
}

vec3 scatter(vec3 coeff, float depth){
	return coeff * depth;
}

vec3 absorb(vec3 coeff, float depth){
	return exp2(scatter(coeff, -depth));
}

float calcParticleThickness(float depth){
    depth = depth * 2.0;
    depth = max(depth + 0.01, 0.01);
    depth = 1.0 / depth;
    return 100000.0 * depth;   
}

float calcParticleThicknessSky(float depth){
	depth = depth * 2.0;
	depth = max(depth + 0.01, 0.01);
	depth = 1.0 / depth;
	return 30000.0 * depth;   
}

vec3 Saturation(vec3 color, float strength) {
    float lum = dot(color, vec3(0.299, 0.587, 0.114)); // luminance
    return mix(vec3(lum), color, strength);
}

float shifted_e_makeup_dither(vec2 frag) {
  vec3 p3 = fract(vec3(frag.xyx) * .1031);
  p3 += dot(p3, p3.yzx + 33.33);
  float p4 = fract((p3.x + p3.y) * p3.z) * 0.175;

  return fract(0.3 * frame_mod + p4 + dot(frag, vec2(0.6180339887498948, 0.8983902273585074)));
}

float getOpticalDepth(float dotUp, float ditherVal) {
    float totalDepth = 0.0;
    int steps = 8;
    float stepSize = 1.0 / float(steps);
    float current = ditherVal * stepSize;
    for (int i = 0; i < steps; i++) {
        totalDepth = calcParticleThicknessSky(dotUp * current);
        current += stepSize;
    }
    return totalDepth;
}

vec3 getSunAbsorption(vec3 viewScatter, vec3 viewAbsorb, vec3 lightScatter, vec3 lightAbsorb) {
    return abs(lightAbsorb - viewAbsorb) / d0((lightScatter - viewScatter) * log(0.7));
}

vec3 getSunEffect(float sunLook, float cloudA, float sunHeight, vec3 viewAbsorb) {
    vec3 sunDisk = (vec3(1.0) * smoothstep(0.99975, 0.999999, sunLook) / mix(0.001, 1.0, cloudA)) * mix(1.0, 0.5, rainStrength);
    vec3 sunHalo = (vec3(1.0, 0.5, 0.1) * pow(clamp(sunLook * 0.5 + 0.5, 0.0, 1.0), 8.0) / 0.08) * mix(mix(1.0, 0.0, tNoon), 0.0, rainStrength);
    float fade = smoothstep(-0.05, 0.1, sunHeight);
    return (sunDisk * 6.0) * viewAbsorb * fade;
}

vec3 getSunEffect_water(float sunLook, float cloudA, float sunHeight, vec3 viewAbsorb) {
    vec3 sunDisk = (vec3(1.0) * smoothstep(0.99, 0.9999999999, sunLook) / mix(0.001, 1.0, cloudA)) * mix(1.0, 0.5, rainStrength);
    vec3 sunHalo = (vec3(1.0, 0.5, 0.1) * pow(clamp(sunLook * 0.5 + 0.5, 0.0, 1.0), 8.0) / 0.08) * mix(mix(1.0, 0.0, tNoon), 0.0, rainStrength);
    float fade = smoothstep(-0.05, 0.1, sunHeight);
    return (sunDisk * 6.0) * viewAbsorb * fade;
}

vec3 getMoonEffect(WorldDirs dirs, float cloudA) {
    vec3 viewDir = normalize(dirs.worldDir);
    vec3 moonDir = normalize(-dirs.sunDir);

    float radius       = 0.0485;
    float falloff      = 0.0015;
    float offsetAmount = 0.0185;

    float cosAngle = clamp(dot(viewDir, moonDir), -1.0, 1.0);
    float angle = acos(cosAngle);

    float disk = smoothstep(radius + falloff, radius, angle);

    vec3 lateral = cross(moonDir, normalize(dirs.upDir));
    if (length(lateral) < 1e-4) lateral = normalize(cross(moonDir, vec3(0.0, 0.0, 1.0)));
    lateral = normalize(lateral);

    vec3 shadowDir = normalize(moonDir + lateral * offsetAmount);

    float cosAngleS = clamp(dot(viewDir, shadowDir), -1.0, 1.0);
    float angleS = acos(cosAngleS);

    float shadow = smoothstep(radius + falloff, radius, angleS);

    float crescent = max(disk - shadow, 0.0);

    float darkSide = disk * 0.005;

    float moonVis = max(crescent, darkSide);

    moonVis /= mix(0.001, 1.0, cloudA);
    moonVis *= mix(1.0, 0.5, rainStrength);
	
	vec3 moonFullColor = vec3(0.45, 0.65, 1.0);
	
    return moonFullColor * moonVis;
}

vec3 getHorizonColTrans1(float sunHeight) {
    vec3 colorStart = vec3(0.98, 0.35, 0.1) * 12.0;
    vec3 colorEnd = vec3(0.1, 0.35, 0.98) * 8.0;
    float mixVal = smoothstep(-0.05, 0.15, sunHeight);
    vec3 col = mix(colorEnd, colorStart, mixVal);
    col += mix(vec3(0.0), vec3(80.0), rainStrength);
    return col;
}

vec3 getHorizonColTrans2(float sunHeight) {
    vec3 colorStart = vec3(0.1, 0.35, 0.98) * 12.0;
    vec3 colorEnd = vec3(0.1, 0.35, 0.98) * 8.0;
    float mixVal = smoothstep(-0.05, 0.15, sunHeight);
    vec3 col = mix(colorEnd, colorStart, mixVal);
    col += mix(vec3(0.0), vec3(80.0), rainStrength);
    return col;
}

vec3 getZenithCol(vec3 sunScatter, vec3 sunAbsorb, float sunHeight, vec3 horizon2Col) {
    vec3 baseCol = (sunScatter * sunAbsorb) / 0.001;
    float sunFac = smoothstep(-0.2, 0.15, sunHeight);
    baseCol = mix(mix(baseCol, horizon2Col, 0.175), vec3(0.12, 0.35, 0.9) * 0.035, (1.0 - sunFac) * 0.6);
    return baseCol;
}

WorldDirs getWorldDirs(vec3 fragPos) { WorldDirs d;
    d.worldDirD = mat3(gbufferModelViewInverse) * normalize(fragPos);
    d.worldDir  = mat3(gbufferModelViewInverse) * normalize(fragPos) * mix(1.6, 6.0, tNoon);
    d.upDir     = mat3(gbufferModelViewInverse) * normalize(up_vec);
    d.sunDir    = mat3(gbufferModelViewInverse) * normalize(sunVec);
    return d;
}

/*
WorldDirs getWorldDirsW(vec3 worldPos) { WorldDirs d;
    d.worldDirD = worldPos;
    d.worldDir  = worldPos;
    d.upDir     = mat3(gbufferModelViewInverse) * normalize(up_vec);
    d.sunDir    = mat3(gbufferModelViewInverse) * normalize(sunVec);
    return d;
}
*/

DotVals getDotVals(WorldDirs d) { DotVals v;
    v.sunLook  = dot(d.sunDir, normalize(d.worldDir));
    v.moonLook  = dot(-d.sunDir, normalize(d.worldDir));
    v.sunUp    = dot(d.sunDir, d.upDir);
    v.upWorld  = dot(d.upDir, d.worldDir);
    v.upWorldD = dot(d.upDir, d.worldDirD);
    return v;
}

DepthVals getDepthVals(float upWorld, float sunUp, float ditherVal) { DepthVals dep;
    dep.viewDepth  = getOpticalDepth(upWorld, ditherVal);
    dep.lightDepth = calcParticleThicknessSky(sunUp);
    return dep;
}

ScatterVals getScatterVals(DepthVals dep, DotVals dots) { ScatterVals s;
    s.viewScatter  = scatter(totalCoeff2Sky, dep.viewDepth);
    s.viewAbsorb   = absorb(totalCoeff2Sky, dep.viewDepth);
    s.lightScatter = scatter(totalCoeffSky, dep.lightDepth);
    s.lightAbsorb  = absorb(totalCoeffSky, dep.lightDepth);
    
    s.sunAbsorb    = getSunAbsorption(s.viewScatter, s.viewAbsorb, s.lightScatter, s.lightAbsorb);
    vec3 mieScat   = scatter(mieCoeff, dep.viewDepth) * hgPhase(dots.sunLook, exp2(-0.000003 * dep.viewDepth) * 0.1);
    vec3 rayScat   = scatter(rayleighCoeff * 0.3, dep.viewDepth) * rayleighPhase(dots.sunLook);
    
    s.sunScatter   = mieScat + rayScat;
    return s;
}

SkyColors getSkyColors(ScatterVals scat, DotVals dots, WorldDirs dirs, float cloudA) { SkyColors c;
    float sunHeight = dot(dirs.sunDir, dirs.upDir);
    c.sunEffect = getSunEffect(dots.sunLook, cloudA, sunHeight, scat.viewAbsorb);
    c.moonEffect = getMoonEffect(dirs, cloudA);
    
    c.horizon = getHorizonColTrans1(sunHeight);
    c.horizon2 = getHorizonColTrans2(sunHeight);
    c.zenith = getZenithCol(scat.sunScatter, scat.sunAbsorb, sunHeight, c.horizon2);
    
    float horizonFactor = clamp(dots.upWorldD * 0.45 + 0.5, 0.0, 1.0);
    vec3 skyCol = mix(c.horizon, c.zenith, pow(horizonFactor, 0.4));
    
    float distFade = pow(1.0 - horizonFactor, 3000.0);
    skyCol *= mix(1.25, 0.6, distFade);
    
    skyCol = mix(skyCol, skyCol * 0.5, tNight);
    
    float saturationBoost = mix(1.0, 1.3, horizonFactor);
    skyCol *= saturationBoost;
    
    skyCol += c.sunEffect + c.moonEffect;
    c.finalCol = pow(0.8 * skyCol * vec3(0.7, 0.8, 0.95), vec3(0.5)) * 0.15;
    return c;
}


SkyColors getSkyColors_water(ScatterVals scat, DotVals dots, WorldDirs dirs, float cloudA) { SkyColors c;
    float sunHeight = dot(dirs.sunDir, dirs.upDir);
    c.sunEffect = getSunEffect_water(dots.sunLook, cloudA, sunHeight, scat.viewAbsorb);
    c.moonEffect = getMoonEffect(dirs, cloudA);
    
    c.horizon = getHorizonColTrans1(sunHeight);
    c.horizon2 = getHorizonColTrans2(sunHeight);
    c.zenith = getZenithCol(scat.sunScatter, scat.sunAbsorb, sunHeight, c.horizon2);
    
    float horizonFactor = clamp(dots.upWorldD * 0.45 + 0.5, 0.0, 1.0);
    vec3 skyCol = mix(c.horizon, c.zenith, pow(horizonFactor, 0.4));
    
    float distFade = pow(1.0 - horizonFactor, 3000.0);
    skyCol *= mix(1.25, 0.6, distFade);
    
    skyCol = mix(skyCol, skyCol * 0.5, tNight);
    
    float saturationBoost = mix(1.0, 1.3, horizonFactor);
    skyCol *= saturationBoost;
    
    skyCol += c.sunEffect + c.moonEffect;
    c.finalCol = pow(0.8 * skyCol * vec3(0.7, 0.8, 0.95), vec3(0.5)) * 0.15;
    return c;
}

vec3 Vibrance(vec3 color, float strength) {
    float intensity = (color.r + color.g + color.b) / 3.0;
    vec3 boost = vec3(color.r * 1.1, color.g * 1.2, color.b * 1.5);
    return mix(color, boost, strength) * (0.8 + intensity * 0.2);
}

/*
vec3 getAtmosphericSky(vec3 worldPos) {
    float ditherVal = shifted_e_makeup_dither(gl_FragCoord.xy);
    
    WorldDirs dirs = getWorldDirsW(worldPos);
    DotVals dots = getDotVals(dirs);
    DepthVals dep = getDepthVals(dots.upWorld, dots.sunUp, ditherVal);
    ScatterVals scat = getScatterVals(dep, dots);
    SkyColors sky = getSkyColors(scat, dots, dirs, 0.0);

    vec3 baseCol = Saturation(sky.finalCol, 1.5) * mix(1.0, 0.8, rainStrength);
    return Vibrance(baseCol, 0.8) * mix(1.0, 0.8, dots.upWorld);
}
*/

vec3 getAtmosphericSky(vec3 fragPos, float cloudA) {
    float ditherVal = shifted_e_makeup_dither(gl_FragCoord.xy);
    
    WorldDirs dirs = getWorldDirs(fragPos);
    DotVals dots = getDotVals(dirs);
    DepthVals dep = getDepthVals(dots.upWorld, dots.sunUp, ditherVal);
    ScatterVals scat = getScatterVals(dep, dots);
    SkyColors sky = getSkyColors(scat, dots, dirs, cloudA);

    vec3 baseCol = Saturation(sky.finalCol, 1.5) * mix(1.0, 0.8, rainStrength);
    return Vibrance(baseCol, 0.8) * mix(1.0 * mix(0.9, 0.9, tNoon), 0.8 * mix(0.8, 1.0, tNoon), dots.upWorldD*1.6);
}

vec3 x3(vec3 x) { return x*x*x; }

vec3 getAtmosphericSky_water(vec3 fragPos, float cloudA) {
    float ditherVal = shifted_e_makeup_dither(gl_FragCoord.xy);
    
    WorldDirs dirs = getWorldDirs(fragPos);
    dirs.worldDir *= 1.5;
    DotVals dots = getDotVals(dirs);
    DepthVals dep = getDepthVals(dots.upWorld, dots.sunUp, ditherVal);
    ScatterVals scat = getScatterVals(dep, dots);
    SkyColors sky = getSkyColors_water(scat, dots, dirs, cloudA);
	
    vec3 baseCol = Saturation(pow(sky.finalCol, vec3(1.0 /1.9)), 1.5) * mix(1.0, 0.8, rainStrength);
    return x3(Vibrance(baseCol, 0.8) * mix(1.0 * mix(1.0, 0.9, tNoon), 0.8 * mix(0.8, 1.0, tNoon), dots.upWorldD*1.6));
}