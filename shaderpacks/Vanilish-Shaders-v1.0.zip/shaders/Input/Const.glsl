const float stp = 0.3;			//size of one step for raytracing algorithm
const float ref = 2.0;			//refinement multiplier
const float inc = 0.3;			//increasement factor at each step
const float sunPathRotation = -40.0; //[-60.0 -55.0 -50.0 -45.0 -40.0 -35.0 -30.0 -25.0 -20.0 -15.0 -10.0 -5.0 0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0]
