// pow screen

float pow2(float x) {
    return x * x;
}
vec2 pow2(vec2 x) {
    return x * x;
}
vec3 pow2(vec3 x) {
    return x * x;
}
vec4 pow2(vec4 x) {
    return x * x;
}
float pow4(float x) {
    return pow2(pow2(x));
}
vec2 pow4(vec2 x) {
    return pow2(pow2(x));
}
vec3 pow4(vec3 x) {
    return pow2(pow2(x));
}
vec4 pow4(vec4 x) {
    return pow2(pow2(x));
}

// clamp screen

float clamp00125(float x) {
    return clamp(x, 0.0, 0.125);
}
vec2 clamp00125(vec2 x) {
    return clamp(x, 0.0, 0.125);
}
vec3 clamp00125(vec3 x) {
    return clamp(x, 0.0, 0.125);
}
vec4 clamp00125(vec4 x) {
    return clamp(x, 0.0, 0.125);
}
