#version 120
#define infsh

#include "/Input/composition2.txt"