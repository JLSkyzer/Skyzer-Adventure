#version 120
#define outvsh

#include "/Input/composition2.txt"