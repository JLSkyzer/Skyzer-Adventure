uniform sampler2D gaux4;

vec3 curve(vec3 x) {
    return 1.0 - x / (1.0 + x);
}

vec3 Tonemap_Uchimura_Modified(vec3 x, float P, float a, float m, float l, float c, float b) {
    float l0 = ((P - m) * l) / a;
    float L0 = m - m / a;
    float L1 = m + (1.0 - m) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = (a * P) / (P - S1);
    float CP = C2 / P;

    vec3 w0 = 1.0 - smoothstep(x, vec3(0.0), vec3(m));
    vec3 w2 = step(m + l0, x);
    vec3 w1 = 1.0 - w0 - w2;

    vec3 T = m * pow(x / m, vec3(c)) + b;
    vec3 S = P - (P - S1) * curve(CP * (x - S0));
    vec3 L = m + a * (x - m);

    return clamp(T * w0 + L * w1 + S * w2, 0.0, 1.0);
}

vec3 toneMapUchimura(vec3 x) {
    const float P = 1.0;   // max display brightness
    const float a = 8.0;   // contrast
    const float m = 0.12;  // linear section start
    const float l = 0.22;  // linear section length
    const float c = 1.5;   // black
    const float b = 0.0;   // pedestal
    return Tonemap_Uchimura_Modified(x, P, a, m, l, c, b);
}

vec3 Tonemap_ACES(vec3 x) {
    // Narkowicz 2015, "ACES Filmic Tone Mapping Curve"
    const float a = 2.51f;
    const float b = 0.03f;
    const float c = 2.43f;
    const float d = 0.59f;
    const float e = 0.14f;
    return (x * (a * x + b)) / (x * (c * x + d) + e);
}

vec3 Tonemap_Lottes(vec3 x) {
    // Lottes 2016, "Advanced Techniques and Optimization of HDR Color Pipelines"
    const float a = 1.6f;
    const float d = 0.977f;
    const float hdrMax = 8.0f;
    const float midIn = 0.18f;
    const float midOut = 0.267f;
    const float b =
        (-pow(midIn, a) + pow(hdrMax, a) * midOut) /
        ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);
    const float c =
        (pow(hdrMax, a * d) * pow(midIn, a) - pow(hdrMax, a) * pow(midIn, a * d) * midOut) /
        ((pow(hdrMax, a * d) - pow(midIn, a * d)) * midOut);
    return pow(x, vec3(a)) / (pow(x, vec3(a * d)) * b + c);
}

vec3 custom_sigmoid(vec3 color) {
	float depth = texture2D(depthtex1, texcoord).z;
    float water = texture2D(gaux4, texcoord).g;
    
    bool isSky = depth == 1.0;
    bool isWater = water > 2.5;
    
    vec3 HDR = color;
    vec3 HDRsky = toneMapUchimura(HDR); 
    
	HDR *= 1.97;
	HDR = pow(HDR, vec3(1.3333)) / 8.0;
	HDR += HDR;
	HDR += HDR;
	HDR = mix(Tonemap_Lottes(HDR), Tonemap_ACES(HDR), 0.5);
	
    return isSky ? HDRsky : HDR;
}

vec3 custom_sigmoid_alt(vec3 color) {
    return custom_sigmoid(color);
}