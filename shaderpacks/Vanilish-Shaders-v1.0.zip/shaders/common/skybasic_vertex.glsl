#include "/lib/config.glsl"

/* Config, uniforms, ins, outs */
uniform mat4 gbufferModelView;

varying vec3 up_vec;
varying vec4 star_data;
varying vec3 sunVec;

#if AA_TYPE > 0
  #include "/src/taa_offset.glsl"
#endif

const float PI = radians(180.0);
const float TAU = radians(360.0);

uniform int worldTime;

float timeAngle = worldTime / 24000.0;

vec3 GetuSunVec() {
        const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
        float ang = fract(timeAngle - 0.25);
        ang = (ang + (cos(ang * PI) * - 0.5 + 0.5 - ang) * 0.333) * TAU;
        return vec3(- sin(ang), cos(ang) * sunRotationData);
 }

vec3 GetSunVec(vec3 uSunVec) {
        const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
        float ang = fract(timeAngle - 0.25);
        ang = (ang + (cos(ang * PI) * - 0.5 + 0.5 - ang) * 0.333) * TAU;
        return normalize((gbufferModelView * vec4(uSunVec * 2000.0, 1.0)).xyz);
 }
 
void main() {
  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
  #if AA_TYPE > 0
    // gl_Position.xy += offsets[frame_mod] * gl_Position.w * pixel_size;
    gl_Position.xy += taa_offset * gl_Position.w;
  #endif
  
	vec3 uSunVec = GetuSunVec();
	sunVec = GetSunVec(uSunVec);
	
  up_vec = normalize(gbufferModelView[1].xyz);
  star_data =
    vec4(
      gl_Color.rgb * .25,
      float(
        gl_Color.r == gl_Color.g &&
        gl_Color.g == gl_Color.b &&
        gl_Color.r > 0.0
      )
    );
}
