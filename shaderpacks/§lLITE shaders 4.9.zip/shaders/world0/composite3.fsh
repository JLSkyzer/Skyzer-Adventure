#version 130
/* MakeUp - LITE shaders 4.9 - composite3.fsh
Render: FSR

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE3_SHADER
#define NO_SHADOWS

#include "/common/composite3_fragment.glsl"
