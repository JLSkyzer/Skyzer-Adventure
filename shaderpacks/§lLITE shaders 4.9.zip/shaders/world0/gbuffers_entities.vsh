#version 120
/* MakeUp - LITE shaders 4.9 - gbuffers_entities.vsh
Render: Droped objects, mobs and things like that

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define GBUFFER_ENTITIES
#define CAVEENTITY_V

#include "/common/solid_blocks_vertex.glsl"
