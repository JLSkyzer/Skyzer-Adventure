#version 120
/* MakeUp - LITE shaders 4.9 - gbuffers_textured.vsh
Render: Particles

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define GBUFFER_TEXTURED

#include "/common/solid_blocks_vertex.glsl"
