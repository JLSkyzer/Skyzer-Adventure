#version 120
/* MakeUp - LITE shaders 4.9 - composite2.fsh
Render: Antialiasing

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE2_SHADER
#define NO_SHADOWS

#include "/common/composite2_fragment.glsl"
