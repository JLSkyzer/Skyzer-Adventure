#version 120
/* MakeUp - LITE shaders 4.9 - deferred.vsh
Render: Ambient occlusion, volumetric clouds

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define DEFERRED_SHADER

#include "/common/deferred_vertex.glsl"
