#version 120
/* MakeUp - LITE shaders 4.9 - composite.fsh
Render: Bloom and volumetric light

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE_SHADER

#include "/common/composite_vertex.glsl"
