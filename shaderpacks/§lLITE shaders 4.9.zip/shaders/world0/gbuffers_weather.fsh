#version 120
/* MakeUp - LITE shaders 4.9 - gbuffers_weather.fsh
Render: Weather

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define GBUFFER_WEATHER
#define SPECIAL_TRANS

#include "/common/solid_blocks_fragment.glsl"