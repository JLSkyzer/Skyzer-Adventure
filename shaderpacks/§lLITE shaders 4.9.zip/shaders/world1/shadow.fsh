#version 120
/* MakeUp - LITE shaders 4.9 - shadow.fsh
Render: Shadowmap

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define SHADOW_SHADER

#include "/common/shadow_fragment.glsl"
