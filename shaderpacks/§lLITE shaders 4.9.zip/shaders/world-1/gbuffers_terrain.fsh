#version 120
/* MakeUp - LITE shaders 4.9 - gbuffers_terrain.fsh
Render: Almost everything

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_TERRAIN
#define FOLIAGE_V
#define NO_SHADOWS

#include "/common/solid_blocks_fragment.glsl"